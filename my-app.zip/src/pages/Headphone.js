import React from "react";
import HeadphoneSection from '../components/HeadphoneSection';

const Headphone = () => {
    return ( 
        <>
            <HeadphoneSection />
        </>
     );
}
 
export default Headphone;