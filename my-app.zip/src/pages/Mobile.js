import React from "react";
import MobileSection from '../components/MobileSection';


const Mobile = () => {
    return ( 
        <>
            <MobileSection />
        </>
     );
}
 
export default Mobile;