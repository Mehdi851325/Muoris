import React from 'react';

const ProductDetail = () => {
    return ( 
        <div>
            
        </div>
     );
}
 
export default ProductDetail;