import React from "react";
import ChargerSection from '../components/ChargerSection';

const Charger = () => {
    return ( 
        <>
            <ChargerSection />
        </>
     );
}
 
export default Charger;