import React from "react";
import Main from "../components/Main";

const Landing = () => {
    return ( 
        <>
            <Main />
        </>
     );
}
 
export default Landing;