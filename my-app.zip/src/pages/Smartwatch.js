import React from "react";
import SmartwatchSection from '../components/SmartwatchSection';

const Smartwatch = () => {
    return ( 
        <>
            <SmartwatchSection />
        </>
     );
}
 
export default Smartwatch;