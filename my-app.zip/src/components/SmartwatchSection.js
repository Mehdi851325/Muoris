import React from "react";

const SmartwatchSection = () => {
    return ( 
        <div>
            <h1>Smart watch</h1>
        </div>
     );
}
 
export default SmartwatchSection;