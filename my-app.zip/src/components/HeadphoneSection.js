import React from "react";

const HeadphoneSection = () => {
    return ( 
        <div>
            <h1>Headphone</h1>
        </div>
     );
}
 
export default HeadphoneSection;