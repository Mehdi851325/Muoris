import React from "react";

const ChargerSection = () => {
    return ( 
        <div>
            <h1>Charegr</h1>
        </div>
     );
}
 
export default ChargerSection;